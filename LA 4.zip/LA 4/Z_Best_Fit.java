public class Z_Best_Fit {
    
    public void bestFit(int blocSize[],int m,int processSize[],int n)
    {
        int allocation[]=new int[n];

        for(int i=0;i<n;i++)
        {
            allocation[i]=-1;
        }

        for(int i=0;i<n;i++)
        {
            int bestIdx=-1;
            for(int j=0;j<n;j++)
            {

            }
        }
    }
}
