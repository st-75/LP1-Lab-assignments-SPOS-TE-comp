public class Main_Fifo {
    public static void main(String[] args) {

        FIFO fifo = new FIFO();
        fifo.execute();
    }

}