public class Main_OPT {
    public static void main(String[] args) {
        Optimal optimal = new Optimal();
        optimal.execute();
    }
}