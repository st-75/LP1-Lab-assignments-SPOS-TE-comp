public class Main_LRU {
    public static void main(String[] args) {
        LRU lru = new LRU();
        lru.execute();
    }
}
